import React from 'react';
import Footer from "../../components/Footer";
import Navbar from "../../components/Navbar";

function TicketList() {
return (
        <div>
            <Navbar />
            <div className="container">
                <div className="row">
                    <div className="col-md-6">
                        <div className="mt-3">
                            <h3 className="text-left rwt-txt-dark-blue">Notifications</h3>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item "><a href="/dashboard" className="bdc rwt-txt-dark-blue text-decoration-none">Dashboard</a></li>
                                    <li class="breadcrumb-item "><a href="/payment" className="bdc rwt-txt-dark-blue text-decoration-none">Notifications</a></li>
                                    <li class="breadcrumb-item active rwt-txt-dark-blue" aria-current="page">Ticket</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <hr />
                </div>
                <div className="row"> 
                    <div class="col-4 bd-highlight">
                        <label class="visually-hidden" for="autoSizingSelect">Preference</label>
                        <select class="form-select" id="autoSizingSelect">
                            <option selected>Location</option>
                            <option value="1">One</option>
                            <option value="2">Two</option>
                            <option value="3">Three</option>
                        </select>
                    </div>
                    <div className="col-4"></div>
                    <div class="col-4 bd-highlight">
                        <div class="form-check">
                            <form class="d-flex">
                                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                                <button class="btn btn-md rwt-primary-btn" type="submit">APPLY</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div className="col-12">
                    <table className="table mt-3 table-striped table-hover">
                        <thead>
                            <tr className="rwt-txt-dark-blue">
                                <th scope="col">Sl No.</th>
                                <th scope="col">Organisation</th>
                                <th scope="col">Location</th>
                                <th scope="col">Date</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr className="rwt-txt-dark-blue">
                                <th scope="row">1</th>
                                <td>RapidWild Group</td>
                                <td>Hubballi, Karnataka</td>
                                <td>2021-10-10</td>
                                <td>Detail</td>
                            </tr>
                            <tr className="rwt-txt-dark-blue">
                                <th scope="row">2</th>
                                <td>RapidWild Group</td>
                                <td>Hubballi, Karnataka</td>
                                <td>2021-10-10</td>
                                <td>Detail</td>
                            </tr>
                            <tr className="rwt-txt-dark-blue">
                                <th scope="row">3</th>
                                <td>RapidWild Group</td>
                                <td>Hubballi, Karnataka</td>
                                <td>2021-10-10</td>
                                <td>Detail</td>
                            </tr>
                            <tr className="rwt-txt-dark-blue">
                                <th scope="row">4</th>
                                <td>RapidWild Group</td>
                                <td>Hubballi, Karnataka</td>
                                <td>2021-10-10</td>
                                <td>Detail</td>
                            </tr>
                            <tr className="rwt-txt-dark-blue">
                                <th scope="row">5</th>
                                <td>RapidWild Group</td>
                                <td>Hubballi, Karnataka</td>
                                <td>2021-10-10</td>
                                <td>Detail</td>
                            </tr>
                            <tr className="rwt-txt-dark-blue">
                                <th scope="row">6</th>
                                <td>RapidWild Group</td>
                                <td>Hubballi, Karnataka</td>
                                <td>2021-10-10</td>
                                <td>Detail</td>
                            </tr>
                            <tr className="rwt-txt-dark-blue">
                                <th scope="row">7</th>
                                <td>RapidWild Group</td>
                                <td>Hubballi, Karnataka</td>
                                <td>2021-10-10</td>
                                <td>Detail</td>
                            </tr>
                            <tr className="rwt-txt-dark-blue">
                                <th scope="row">8</th>
                                <td>RapidWild Group</td>
                                <td>Hubballi, Karnataka</td>
                                <td>2021-10-10</td>
                                <td>Detail</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <Footer />
        </div>
    )
}

export default TicketList; 
