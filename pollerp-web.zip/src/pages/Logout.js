import React,{useState} from 'react';
import { useForm } from "react-hook-form";
import axios from 'axios';
import Logo from '../components/Logo';
import '../assets/css/Core.css';

function Logout() {
    const url =  "";
    const [InputFields, setInputFields] = useState({
        username: "", 
        password: "", 
    })

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        trigger,
    } = useForm();

    const onSubmit = (data) => { 
        axios.post(url, data).then(res => {
            console.log(res.data)
        }).catch(err => console.log(err))
        reset()
    };

    return (
        <div>
            <div className="container">
                <div className="row">
                    <div className="col-md-4 offset-md-4">
                        <div className="login-form bg-light mt-4 p-4">
                            <form action="" method="" className="row g-3" onSubmit={handleSubmit(onSubmit)}>
                                <div className="text-center">
                                    <Logo />
                                </div>
                                <div className="col-12">
                                    <label className="rwt-txt-dark-blue">Username</label>
                                    <input type="text" className={`form-control ${errors.username && "invalid"}`}
                                        {...register("username", { required: "Username is Required" })}
                                        onKeyUp={() => {
                                            trigger("username");
                                        }} className="form-control" placeholder="Username" />
                                    {errors.username && (
                                        <small className="text-danger">{errors.username.message}</small>
                                    )}
                                </div>
                                <div className="col-12">
                                    <label className="rwt-txt-dark-blue">Password</label>
                                    <input type="password" className={`form-control ${errors.password && "invalid"}`}
                                        {...register("password", { required: "Password is Required" })}
                                        onKeyUp={() => {
                                            trigger("password");
                                        }} className="form-control" placeholder="Password" />
                                    {errors.password && (
                                        <small className="text-danger">{errors.password.message}</small>
                                    )}
                                </div>
                                <div className="col-12">
                                    <div className="form-check">
                                        <input className="form-check-input" type="checkbox" id="rememberMe" />
                                        <label className="form-check-label rwt-txt-dark-blue" for="rememberMe"> Remember me</label>
                                    </div>
                                </div>
                                <div className="col-12 d-grid gap-2 col-6 mx-auto">
                                    <button type="submit" className="rwt-primary-btn btn-sm btn btn-outline-none"><a href="/dashboard" className="text-decoration-none"><h6 className=" text-white mt-2 ">Login</h6></a></button>
                                </div>
                            </form>
                            <hr className="mt-4" />
                            <div className="col-12">
                                <p className="text-center mb-0 rwt-txt-dark-blue">Forgot your Password? <a href="/password" className="foot-link rwt-txt-dark-blue"> Reset Password</a></p>
                            </div>
                        </div>
                    </div>
                    <div className="text-center rwt-txt-dark-blue mt-4">
                        &copy; 2021,  Developed And Maintained by
                        <a href="https://rapidwildtechnologies.com/" className="foot-link rwt-txt-dark-blue text-decoration-none fw-bold"> Rapidwild Technologies</a>
                    </div>
                </div>
            </div>
        </div >
    )
}

export default Logout;
