import React, { useState } from 'react';
import { useForm } from "react-hook-form";
import axios from 'axios'
import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'

function Setting() {
    const url = "";
    const [InputFields, setInputFields] = useState({
        emailcount: "",
        smscount: "",
        emailid: "",
        password: "",
    })

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset,
        trigger,
    } = useForm();

    const {
        register: register2,
        handleSubmit: handleSubmit2,
        formState: { errors: errors2 },
        reset: reset2,
        trigger: trigger2,
    } = useForm();

    const onSubmit = (data) => {
        axios.post(url, data).then(res => {
            console.log(res.data)
        }).catch(err => console.log(err))
        reset() 
    };

    const onSubmitSettings = (data) => {
        axios.post(url, data).then(res => {
            console.log(res.data)
        }).catch(err => console.log(err))
        reset2() 
    };
    return (
        <>
            <Navbar />
            <div className="container">
                <div className="row">
                    <div className="col-md-6">
                        <div className="mt-3">
                            <h3 className="text-left rwt-txt-dark-blue">Settings</h3>
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb">
                                    <li className="breadcrumb-item "><a href="/dashboard" className="bdc rwt-txt-dark-blue text-decoration-none">Dashboard</a></li>
                                    <li className="breadcrumb-item active rwt-txt-dark-blue" aria-current="page">Settings</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <hr />
                    <div className="col-md-10 offset-md-1">
                        <div className="py-3">
                            <div className="login-form shadow shadow-intensity-md rounded-3 mt-4 p-4">
                                <form action="" method="" className="row g-3 p-3" onSubmit={handleSubmit(onSubmit)}>
                                    <div className="row">
                                        <div className="col-md-12 mt-4">
                                            <div className="text-left rwt-txt-dark-blue">
                                                <h3><b>Packages</b></h3>
                                            </div>
                                        </div>
                                        <div className="col-md-6 mt-3">
                                            <label className="form-label">Available SMS</label>
                                            <div>-</div>
                                        </div>
                                        <div className="col-md-6 mt-3">
                                            <label className="form-label">Available Email</label>
                                            <div>-</div>
                                        </div>
                                        <div className="col-md-6 mt-3">
                                            <label className="form-label">Update SMS Count</label>
                                            <input type="number" name="smscount" className={`form-control ${errors.smscount && "invalid"}`}
                                                {...register("smscount", { required: "SMS Count is Required" })}
                                                onKeyUp={() => {
                                                    trigger("smscount");
                                                }} placeholder="Update SMS Count" />
                                            {errors.smscount && (
                                                <small className="text-danger">{errors.smscount.message}</small>
                                            )}
                                        </div>
                                        <div className="col-md-6 mt-3">
                                            <label className="form-label">Update Email Count</label>
                                            <input type="number" name="emailcount" className="form-control" className={`form-control ${errors.emailcount && "invalid"}`}
                                                {...register("emailcount", { required: "Email Count is Required" })}
                                                onKeyUp={() => {
                                                    trigger("emailcount");
                                                }} placeholder="Update Email Count" />
                                            {errors.emailcount && (
                                                <small className="text-danger">{errors.emailcount.message}</small>
                                            )}
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="text-end mt-4">
                                            <button type="submit" className="rwt-primary-btn text-end btn-lg text-white btn btn-outline-none">SAVE RECORD</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div className="col-md-10 offset-md-1">
                        <div className="py-3">
                            <div className="login-form shadow shadow-intensity-md rounded-3 mt-4 p-4">
                                <form action="" method="" className="row g-3 p-3" onSubmit={handleSubmit2(onSubmitSettings)}>
                                    <div className="row">
                                        <div className="col-md-12 mt-4">
                                            <div className="text-left rwt-txt-dark-blue">
                                                <h3><b>Acccount Settings</b></h3>
                                            </div>
                                        </div>
                                        <div className="col-md-6 mt-3">
                                            <label className="form-label">Update Email</label>
                                            <input type="email" name="emailid" className={`form-control ${errors2.emailid && "invalid"}`}
                                                {...register2("emailid", { required: "Email Id is Required" })}
                                                onKeyUp={() => {
                                                    trigger2("emailid");
                                                }} placeholder="Enter Email Id" />
                                            {errors2.emailid && (
                                                <small className="text-danger">{errors2.emailid.message}</small>
                                            )}
                                        </div>
                                        <div className="col-md-6 mt-3">
                                            <label className="form-label">Update Password</label>
                                            <input type="password" name="password" className={`form-control ${errors2.password && "invalid"}`}
                                                {...register2("password", { required: "Password is Required" })}
                                                onKeyUp={() => {
                                                    trigger2("password");
                                                }} placeholder="Enter Password" />
                                            {errors2.password && (
                                                <small className="text-danger">{errors2.password.message}</small>
                                            )}
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="text-end mt-4">
                                            <button type="submit" className="rwt-primary-btn text-end btn-lg text-white btn btn-outline-none">SAVE RECORD</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />
        </>
    )
}

export default Setting
