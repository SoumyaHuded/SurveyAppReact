import React from 'react'
import Logo from '../components/Logo';
import '../assets/css/Core.css';
import Footer from '../components/Footer';

function Password() {
    return (
        <div>
            <div className="container">
                <div className="row">
                    <div className="col-md-4 offset-md-4">
                        <div className="login-form bg-light mt-4 p-4">
                            <form action="" method="" className="row g-3">
                                <div className="text-center mb-3 mt-4">
                                    <Logo />
                                </div>
                                <div>
                                    <h4>Forgot Your Password ?</h4>
                                    <p>Enter your email address and we will send you instructions to reset your password</p>
                                </div>
                                <div className="col-12 mb-3">
                                    <label className="mb-2">Email address or Number</label>
                                    <input type="text" name="username" className="form-control" placeholder="Enter your email" />
                                </div>
                                <div className="col-12 d-grid gap-2 col-6 mx-auto">
                                    <button type="submit" className="rwt-bg-dark-blue btn-sm mb-3"><a href="/dashboard" className="text-decoration-none"><h6 className="rwt-txt-orange mt-2">Reset password</h6></a></button>
                                </div>
                            </form>
                            <div className="col-12">
                                <p className="text-center mb-0"><a href="/logout">Back to Login</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Footer />

        </div>
    )
}

export default Password
