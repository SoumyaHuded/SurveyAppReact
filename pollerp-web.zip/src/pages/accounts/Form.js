import React, { useState } from 'react';
import { useParams } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { ToastContainer, toast } from 'react-toastify';
import axios from "axios";
import Footer from "../../components/Footer";
import Navbar from "../../components/Navbar";
import State from "../../components/State";
import City from "../../components/City";
import Locationpin from "../../components/Pincode";
import "../../assets/css/Form.css";
import Config from "../../config/index";
const CryptoJS = require("crypto-js");

function AddAcc() {
    const { id } = useParams();
    const submitUrl = `${Config.apiUrl}accounts.php/accounts`;
    const getUrl = `${Config.apiUrl}accounts.php/accounts-row?accId=${(id) ? id : 0}`;
    const [InputFields, setInputFields] = useState({
        organisation: "",
        email: "",
        phone: "",
        password: "",
        address: "",
        package: "",
        status: "",
        emailcount: "",
        smscount: "",
        city: "",
        state: "",
        pincode: "",
    });
    const [SubmitButton, setSubmitButton] = useState('SAVE RECORD');
    const [Notification, setNotification] = useState({ status: (id) ? true : false, message: 'Please wait while we fetch your record' })
    const [DisableSubmitButton, setDisableSubmitButton] = useState(false);
    const {
        register,
        handleSubmit,
        control,
        formState: { errors },
        reset
    } = useForm();

    const handleStateConfig = ((key, val) => {
        const newData = { ...InputFields }
        newData[key] = val
        setInputFields(newData)
    })

    const handlePackageChange=((val)=>{ 
        handleStateConfig('package', val.target.value) 
    })
    
    const handleStatusChange=((val)=>{ 
        handleStateConfig('status', val.target.value) 
    })

    const onSubmit = (data) => {
        setSubmitButton('LOADING...');
        setDisableSubmitButton(true);
        const ciphertext = CryptoJS.AES.encrypt(Config.secretKey, data.password).toString();
        axios({
            url: submitUrl,
            method: (data.id) ? 'patch' : 'POST',
            data: {
                id: data.id,
                name: data.organisation,
                email: data.email,
                phoneNo: data.phone,
                password: ciphertext,
                address: data.address,
                package: data.package,
                status: data.status,
                emailCount: data.emailcount,
                smsCount: data.smscount,
                state: InputFields.state,
                city: InputFields.city,
                pincode: InputFields.pincode
            },
            headers: {
                "content-type": "application/json",
                "Accept": "application/json"
            }
        }).then(res => {
            setSubmitButton('SAVE RECORD');
            toast.info('Great Success, Have a tea :)');
            reset();
            setDisableSubmitButton(false);
        }).catch((err) => {
            setSubmitButton('SAVE RECORD');
            toast.error('Something went wrong :(');
            setDisableSubmitButton(false);
        })
    };
    // Get data from DB - Used for Edit option
    React.useEffect(() => {
        if (id) {
            axios.get(getUrl).then((response) => {
                var config = {
                    id: response.data[0].id,
                    organisation: response.data[0].name,
                    email: response.data[0].email,
                    phone: response.data[0].phone_no,
                    address: response.data[0].address,
                    package: response.data[0].packages_id,
                    status: response.data[0].status,
                    emailcount: response.data[0].email_count,
                    smscount: response.data[0].sms_count,
                    city: response.data[0].city_id,
                    state: response.data[0].state_id,
                    pincode: response.data[0].pincode_id
                }
                setInputFields(config)
                setNotification({ status: false })
            }).catch((err) => {
                setNotification({ status: true, message: 'Sorry something went wrong while fetching record :(' })
            })
        }
    }, []);
    return (
        <>
            <Navbar />
            <div className="container">
                <div className="row">
                    <div className="col-md-6">
                        <div className="mt-3">
                            <h3 className="text-left rwt-txt-dark-blue">Add Accounts</h3>
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb">
                                    <li className="breadcrumb-item "><a href="/dashboard" className="bdc rwt-txt-dark-blue text-decoration-none">Dashboard</a></li>
                                    <li className="breadcrumb-item active rwt-txt-dark-blue" aria-current="page">Accounts</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="text-right d-flex justify-content-end h-100 align-items-center">
                            <a href="/accounts" className="rwt-primary-btn btn-md btn btn-outline-none text-white">VIEW ACCOUNT</a>
                        </div>
                    </div>
                    <hr />
                    <div className="col-md-10 offset-md-1 ">
                        <div className="py-3">
                            <div className="login-form shadow shadow-intensity-md rounded-3 mt-4 p-4">
                                <form action="" method="" className="row g-3 p-5 " onSubmit={handleSubmit(onSubmit)}>
                                    <div className="row">
                                        {(Notification.status) ?
                                            <div className="col-12 text-center">{Notification.message}</div> : <>
                                                <div className="col-md-12">
                                                    <div className="text-left mt-3 rwt-txt-dark-blue">
                                                        <h3><b>Basic Information</b></h3>
                                                    </div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label">Account type</label>
                                                    <select className="form-control custom-select" name="accounttype" {...register("accounttype", { required: true })}>
                                                        <option value> Choose...</option>
                                                        <option value="1"> Individual</option>
                                                        <option value="2"> Organisation</option> 
                                                    </select>
                                                    <small className="form-text text-danger">
                                                        {errors.accounttype?.type === "required" && "Please update account type"}
                                                    </small>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label">Account</label>
                                                    <input className="form-control" type="text" name="organisation" defaultValue={InputFields.organisation} placeholder="Enter Account Name" {...register("organisation", { required: true, minLength: 3 })} />
                                                    <small className="form-text text-danger">
                                                        {errors.organisation?.type === "required" && "Organisation name is mandatory"}
                                                    </small>
                                                    <small className="form-text text-danger">
                                                        {errors.organisation?.type === "minLength" && "Enter atleast 3 characters"}
                                                    </small>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label">Email</label>
                                                    <input type="text" name="email" defaultValue={InputFields.email} placeholder="Enter Email Id" className="form-control"{...register("email", { required: true, pattern: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i })} />
                                                    <small className="form-text text-danger">
                                                        {errors.email?.type === "required" && "Email Id is mandatory"}
                                                    </small>
                                                    <small className="form-text text-danger">
                                                        {errors.email?.type === "pattern" && "Enter valid email address"}
                                                    </small>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label">Phone No.</label>
                                                    <input type="text" name="phone" defaultValue={InputFields.phone} placeholder="Enter Phone No." className="form-control"{...register("phone", { required: true, pattern: /^\d{10}$/ })} />
                                                    <small className="form-text text-danger">
                                                        {errors.phone?.type === "required" && "Phone No. is mandatory"}
                                                    </small>
                                                    <small className="form-text text-danger">
                                                        {errors.phone?.type === "pattern" && "Enter valid phone no."}
                                                    </small>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label">Password</label>
                                                    <input type="password" name="password"  placeholder="Enter Password" className="form-control"{...register("password", { required: (id) ? false : true, pattern: /(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/ })} />
                                                    <small className="form-text text-danger">
                                                        {errors.password?.type === "required" && "Enter password"}
                                                    </small>
                                                    <small className="form-text text-danger">
                                                        {errors.password?.type === "pattern" && "Password should include UpperCase, LowerCase, Number/SpecialChar and min 8 Chars"}
                                                    </small>
                                                </div>
                                                <div className="col-md-12 mt-4">
                                                    <div className="text-left mt-3 rwt-txt-dark-blue">
                                                        <h3><b>Contact Information</b></h3>
                                                    </div>
                                                </div>
                                                <div className="col-md-12 mt-3">
                                                    <label className="form-label">Address</label>
                                                    <textarea defaultValue={InputFields.address} className="form-control" {...register("address", { required: true, minLength: 20 })}></textarea>
                                                    <small className="form-text text-danger">
                                                        {errors.address?.type === "required" && "Organisation Address is mandatory"}
                                                    </small>
                                                    <small className="form-text text-danger">
                                                        {errors.address?.type === "minLength" && "Enter atleast 20 characters"}
                                                    </small>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label">State</label>
                                                    <State register={register} errors={errors} selectedValue={InputFields.state} locationFunction={handleStateConfig} />
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label">City</label>
                                                    <City register={register} errors={errors} selectedValue={InputFields.city} locationFunction={handleStateConfig}/>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label">Pin code</label>
                                                    <Locationpin register={register} errors={errors} selectedValue={InputFields.pincode} locationFunction={handleStateConfig} />
                                                </div>
                                                <div className="col-md-12 mt-4">
                                                    <div className="text-left mt-4 rwt-txt-dark-blue">
                                                        <h3><b>Other Information</b></h3>
                                                    </div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label">Packages</label>
                                                    <select value={InputFields.package} className="form-control custom-select" name="package" {...register("package", { required: true })} onChange={handlePackageChange}>
                                                        <option value=""> Choose...</option>
                                                        <option value={1}> Basic</option>
                                                        <option value={2}> Silver</option>
                                                        <option value={3}> Gold</option>
                                                    </select>
                                                    <small className="form-text text-danger">
                                                        {errors.package?.type === "required" && "Please update package"}
                                                    </small>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label">Status</label>
                                                    <select value={InputFields.status} className="form-control custom-select" name="status"{...register("status", { required: true })} onChange={handleStatusChange}>
                                                        <option value=""> Choose...</option>
                                                        <option value={1}>Active</option>
                                                        <option value={0}>Inactive</option>
                                                    </select>
                                                    <small className="form-text text-danger">
                                                        {errors.status?.type === "required" && "Please update status"}
                                                    </small>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label">Available SMS</label>
                                                    <div>-</div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label">Available Email</label>
                                                    <div>-</div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label">Update SMS Count</label>
                                                    <input type="number" name="smscount" defaultValue={InputFields.smscount} placeholder="Update SMS Count" className="form-control"{...register("smscount", { required: true })} />
                                                    <small className="form-text text-danger">
                                                        {errors.smscount?.type === "required" && "Update sms count"}
                                                    </small>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label">Update Email Count</label>
                                                    <input type="number" name="emailcount" defaultValue={InputFields.emailcount} placeholder="Update Email Count" className="form-control"{...register("emailcount", { required: true })} />
                                                    <small className="form-text text-danger">
                                                        {errors.emailcount?.type === "required" && "Update email count"}
                                                    </small>
                                                </div>
                                                <div className="col-12 text-end">
                                                    <button type="submit" disabled={DisableSubmitButton} className="rwt-primary-btn text-end btn-lg text-white btn btn-outline-none mt-4">{SubmitButton}</button>
                                                </div>
                                            </>}
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <ToastContainer
                position="top-right"
                autoClose={5000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
            />
            <Footer />
        </>
    )
}

export default AddAcc;