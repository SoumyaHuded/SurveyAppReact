import React, { useState } from 'react';
import { useParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import { ToastContainer, toast } from 'react-toastify';
import axios from "axios";
import Footer from "../../components/Footer";
import Navbar from "../../components/Navbar";
import State from "../../components/State";
import City from "../../components/City";
import Locationpin from "../../components/Pincode";
import "../../assets/css/Form.css";
import Config from "../../config/index"; 
const CryptoJS = require("crypto-js");

function View() {
    const { id } = useParams();
    const submitUrl = `${Config.apiUrl}accounts.php/accounts`;
    const getUrl = `${Config.apiUrl}accounts.php/accounts-row?accId=${(id) ? id : 0}`;
    const [InputFields, setInputFields] = useState({
        organisation: "",
        email: "",
        phone: "",
        password: "",
        address: "",
        package: "",
        status: "",
        emailcount: "",
        smscount: "",
        city: "",
        state: "",
        pincode: "",
    });
    const [SubmitButton, setSubmitButton] = useState('SAVE RECORD');
    const [Notification, setNotification] = useState({ status: (id) ? true : false, message: 'Please wait while we fetch your record' })
    const [DisableSubmitButton, setDisableSubmitButton] = React.useState(false);

    const {
        register,
        handleSubmit,
        formState: { errors },
        reset, 
    } = useForm();

    const handleStateConfig = ((key, val) => {
        const newData = { ...InputFields }
        newData[key] = val
        setInputFields(newData)
    })

    const onSubmit = (data) => {
        setSubmitButton('LOADING...');
        setDisableSubmitButton(true);
        const ciphertext = CryptoJS.AES.encrypt(Config.secretKey, data.password).toString();
        axios({
            url: submitUrl,
            method: (data.id) ? 'patch' : 'POST',
            data: {
                id: data.id,
                name: data.organisation,
                email: data.email,
                phoneNo: data.phone,
                password: ciphertext,
                address: data.address,
                package: data.package,
                status: data.status,
                emailCount: data.emailcount,
                smsCount: data.smscount,
                state: InputFields.state,
                city: InputFields.city,
                pincode: InputFields.pincode
            },
            headers: {
                "content-type": "application/json",
                "Accept": "application/json"
            }
        }).then(res => {
            setSubmitButton('SAVE RECORD');
            toast.info('Great Success, Have a tea :)');
            setDisableSubmitButton(false);
            reset();
        }).catch((err) => {
            setSubmitButton('SAVE RECORD');
            toast.error('Something went wrong :(');
            setDisableSubmitButton(false);
        })
    };
    // Get data from DB - Used for Edit option
    React.useEffect(() => {
        if (id) {
            axios.get(getUrl).then((response) => {
                var config = {
                    id: response.data[0].id,
                    organisation: response.data[0].name,
                    email: response.data[0].email,
                    phone: response.data[0].phone_no,
                    address: response.data[0].address,
                    package: response.data[0].packages_id,
                    status: response.data[0].status,
                    emailcount: response.data[0].email_count,
                    smscount: response.data[0].sms_count,
                    city: response.data[0].city_id,
                    state: response.data[0].state_id,
                    pincode: response.data[0].pincode_id
                }
                setInputFields(config)
                setNotification({ status: false })
                setDisableSubmitButton(false);
            }).catch((err) => {
                setNotification({ status: true, message: 'Sorry something went wrong while fetching record :(' })
            })
        }
    }, []);
    return (
        <>
            <Navbar />
            <div className="container">
                <div className="row">
                    <div className="col-md-6">
                        <div className="mt-3">
                            <h3 className="text-left rwt-txt-dark-blue">Add Accounts</h3>
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb">
                                    <li className="breadcrumb-item "><a href="/dashboard" className="bdc rwt-txt-dark-blue text-decoration-none">Dashboard</a></li>
                                    <li className="breadcrumb-item active rwt-txt-dark-blue" aria-current="page">Accounts</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="text-right d-flex justify-content-end h-100 align-items-center">
                            <a href="/accounts" className="rwt-primary-btn btn-md btn btn-outline-none text-white">VIEW ACCOUNT</a>
                        </div>
                    </div>
                    <hr />
                    <div className="col-md-10 offset-md-1 ">
                        <div className="py-3">
                            <div className="login-form shadow shadow-intensity-md rounded-3 mt-4 p-4">
                                <form action="" method="" className="row g-3 p-5 " onSubmit={handleSubmit(onSubmit)}>
                                    <div className="row">
                                        {(Notification.status) ?
                                            <div className="col-12 text-center">{Notification.message}</div> : <>
                                                <div className="col-md-12">
                                                    <div className="text-left mt-3 rwt-txt-dark-blue">
                                                        <h3><b>Basic Information</b></h3>
                                                    </div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label fw-bold">Account :</label>
                                                    <div>{InputFields.organisation}</div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label fw-bold">Email :</label>
                                                    <div>{InputFields.email}</div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label fw-bold">Phone No. :</label>
                                                    <div>{InputFields.phone}</div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label fw-bold">Password :</label> 
                                                    <div>{InputFields.password}</div>
                                                </div>
                                                <div className="col-md-12 mt-4">
                                                    <div className="text-left mt-3 rwt-txt-dark-blue">
                                                        <h3><b>Contact Information</b></h3>
                                                    </div>
                                                </div>
                                                <div className="col-md-12 mt-3">
                                                    <label className="form-label fw-bold">Address :</label> 
                                                    <div>{InputFields.address}</div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label fw-bold">State :</label>
                                                    <div>{InputFields.state}</div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label fw-bold">City :</label>
                                                    <div>{InputFields.city}</div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label fw-bold">Pin code :</label>
                                                    <div>{InputFields.pincode}</div>
                                                </div>
                                                <div className="col-md-12 mt-4">
                                                    <div className="text-left mt-4 rwt-txt-dark-blue">
                                                        <h3><b>Other Information</b></h3>
                                                    </div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label fw-bold">Packages :</label>
                                                    <div>{InputFields.package}</div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label fw-bold">Status :</label>
                                                    <div>{InputFields.status}</div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label fw-bold" disabled readonly>Available SMS :</label>
                                                    <div>-</div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label fw-bold" disabled readonly>Available Email :</label>
                                                    <div>-</div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label fw-bold">Update SMS Count :</label>
                                                    <div>{InputFields.smscount}</div>
                                                </div>
                                                <div className="col-md-6 mt-3">
                                                    <label className="form-label fw-bold">Update Email Count :</label>
                                                    <div>{InputFields.emailcount}</div>
                                                </div> 
                                            </>}
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <ToastContainer
                position="top-right"
                autoClose={5000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
            />
            <Footer />
        </>
    )
}

export default View;