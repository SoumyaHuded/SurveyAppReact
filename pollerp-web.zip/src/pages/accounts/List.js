import React, { useState, useRef, useEffect } from 'react'
import axios from "axios";
import Footer from "../../components/Footer";
import Navbar from "../../components/Navbar";
import ReactPaginate from 'react-paginate';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faEye, faTrashAlt } from '@fortawesome/free-solid-svg-icons';
import Config from "../../config/index";
import ConfirmWindow from "../../components/ConfirmWindow"
import { ToastContainer, toast } from 'react-toastify';
import Record404 from '../../components/Record404';

function Account() {
    //calling child function //
    const invokeConfirmationBox = useRef(null)
    const closeConfirmationBox = useRef(null)
    const [DisableSubmitButton, setDisableSubmitButton] = useState(false);
    const deleteRecord = (id) => {
        setDisableSubmitButton(true)
        axios.delete(`${Config.apiUrl}accounts.php/accounts`, { data: { accId: id } })
            .then(res => {
                toast.info('Record deleted successfully');
                setDisableSubmitButton(false)
                closeConfirmationBox.current.hideModal()
                getRecords()
                console.log(res)
            }).catch((err) => {
                toast.error('Something went wrong :(');
                closeConfirmationBox.current.hideModal()
                console.log(err)
            })
    }
    const getRecords = () => {
        axios.get(`${Config.apiUrl}accounts.php/accounts?accId=1`).then((response) => {
            setPost(response.data);
        });
    }
    const [post, setPost] = useState(null);
    useEffect(() => {
        getRecords()
    }, []);
    
    return (
        <>
            <Navbar />
            <div className="container">
                <div className="row">
                    <div className="col-md-6">
                        <div className="mt-3">
                            <h3 className="text-left rwt-txt-dark-blue">View Accounts</h3>
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb">
                                    <li className="breadcrumb-item "><a href="/dashboard" className="bdc rwt-txt-dark-blue text-decoration-none">Dashboard</a></li>
                                    <li className="breadcrumb-item active rwt-txt-dark-blue" aria-current="page">Accounts</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="text-right d-flex justify-content-end h-100 align-items-center">
                            <a href="/accounts/add" className="rwt-primary-btn btn-md btn btn-outline-none text-white">ADD ACCOUNT</a>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <hr />
                    <div className="col-12">
                        <div className="row">
                            <div className="col-2 ">
                                <select className="form-select" id="autoSizingSelect">
                                    <option value="">Location</option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select>
                            </div>
                            <div className="col-2">
                                <select className="form-select" id="autoSizingSelect">
                                    <option value="">Status</option>
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>
                            <div className="col-4"></div>
                            <div className="col-4 ">
                                <div className="form-check">
                                    <form className="d-flex">
                                        <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
                                        <button className="btn btn-md rwt-primary-btn" type="submit">APPLY</button>
                                    </form>
                                    {/* <a href="/addacc" className="rwt-primary-btn btn-sm btn  text-white">Apply filter</a> */}

                                </div>
                            </div>
                        </div>
                    </div>
                    {(post) ? 
                        <div className="col-12">
                            <table className="table mt-3 table-striped table-hover">
                                <thead>
                                    <tr className="rwt-txt-dark-blue">
                                        <th scope="col">Sl No.</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Location</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {(post) ? post.map((element, index) => {
                                        return (<tr className="rwt-txt-dark-blue" key={Math.random()}>
                                            <th scope="row">{index+1}</th>
                                            <td>{element.name}</td>
                                            <td>{element.state_name}, {element.city_name}</td>
                                            <td>{(element.status) ? 'Active' : 'Inactive'}</td>
                                            <td>
                                                <a href={`accounts/edit/${element.id}`} className="icon px-2 rwt-txt-blue" data-toggle="tooltip" data-placement="top" title="Edit">
                                                    <FontAwesomeIcon icon={faEdit} className="fa-lg" />
                                                </a>
                                                <a href={`accounts/view/${element.id}`} className="icon px-2 rwt-txt-blue" data-toggle="tooltip" data-placement="top" title="View">
                                                    <FontAwesomeIcon icon={faEye} className="fa-lg" />
                                                </a>
                                                <button className="bg-transparent border-0 icon px-2 rwt-txt-orange" onClick={() => invokeConfirmationBox.current(element.id)}>
                                                    <FontAwesomeIcon icon={faTrashAlt} className="fa-lg" />
                                                </button>
                                            </td>
                                        </tr>)
                                    }) : ''}
                                </tbody>
                            </table>
                        </div>
                    : <Record404 />}
                </div>
                <ReactPaginate
                    previousLabel={'previous'}
                    nextLabel={'next'}
                    breakLabel={'...'}
                    breakClassName={'break-me'}
                    pageCount={50}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={5}
                    // onPageChange={this.handlePageClick}
                    containerClassName={'pagination pagination-flush'}
                    breakClassName={'page-item'}
                    breakLinkClassName={'page-link'}
                    pageClassName={'page-item'}
                    pageLinkClassName={'page-link'}
                    previousClassName={'page-item'}
                    previousLinkClassName={'page-link'}
                    nextClassName={'page-item'}
                    nextLinkClassName={'page-link'}
                    activeClassName={'active'}
                />
            </div>
            <ConfirmWindow invokeConfirmationBox={invokeConfirmationBox} deleteRecord={deleteRecord} DisableSubmitButton={DisableSubmitButton} closeConfirmationBox={closeConfirmationBox} />
            <ToastContainer
                position="top-right"
                autoClose={5000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
            />
            <Footer />
        </>
    )
}
export default Account;