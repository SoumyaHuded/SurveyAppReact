import React from 'react'

function Footer() {
    return (
        <> <footer className="bg-light text-center border-top text-lg-start p-3">
            <div className="text-center rwt-txt-dark-blue">
                &copy; 2021, Developed and Maintained by
                <a href="https://rapidwildtechnologies.com/" className="foot-link rwt-txt-dark-blue text-decoration-none fw-bold"> RapidWild Technologies</a>
            </div>
            <div className="text-center rwt-txt-dark-blue">
                For all Legal Notices and Queries please email us on: 
                <a href="mailto:info@rapidwildtechnologies.com" className="foot-link rwt-txt-dark-blue text-decoration-none"> info@rapidwildtechnologies.com</a>
            </div>
        </footer>
        </>
    )
}

export default Footer;
