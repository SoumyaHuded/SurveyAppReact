import React from 'react'
import axios from "axios";
import Config from "../config/index";

function Locationpin(props) {
    const baseURL = `${Config.apiUrl}pincode.php/pincode?pincode=567756`;
    const [Pin, setPin] = React.useState(null);
    React.useEffect(() => {
        axios.get(baseURL).then((response) => {
            setPin(response.data);
        });
    }, []); 
    const handleChange=((val)=>{ 
        props.locationFunction('pincode', val.target.value) 
    })
    React.useEffect(() => {
    },[props.selectedValue])

    if (!Pin) return <div>Loading pincode values</div>;
    return (
        <>
            <select {...props.register("pincode", { required: true })} value={props.selectedValue} className="form-control custom-select" onChange={handleChange}>
                <option value=""> Choose...</option>
                {(Pin) ? Pin.map((element) => {
                    return (<option key={Math.random()} value={element.id}>{element.pincode}</option>)
                }) : ''}
            </select>
            <small className="form-text text-danger">
                {props.errors.pincode?.type === "required" && "Pincode is mandatory"}
            </small>
        </>
    )
}
export default Locationpin;