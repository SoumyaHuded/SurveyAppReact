import React from 'react'
import axios from "axios";
import Config from "../config/index";

function LocationCity(props) {
    const baseURL = `${Config.apiUrl}city.php/city?token=234`;
    const [City, setCity] = React.useState(null);
    React.useEffect(() => {
        axios.get(baseURL).then((response) => {
            setCity(response.data);
        });
    }, []); 
    const handleChange=((val)=>{ 
        props.locationFunction('city', val.target.value) 
    })
    React.useEffect(() => {
    },[props.selectedValue])

    if (!City) return <div>Loading city values</div>;
    return (
        <>
            <select {...props.register("city", { required: true })} value={props.selectedValue} className="form-control custom-select" onChange={handleChange} >
                <option value=""> Choose...</option>
                {(City) ? City.map((element) => {
                    return (<option key={Math.random()} value={element.id}>{element.name}</option>)
                }) : ''}
            </select>
            <small className="form-text text-danger">
                {props.errors.city?.type === "required" && "City is mandatory"}
            </small>
        </>
    )
}
export default LocationCity;