import React from 'react'
function Record404() {
    return (
        <div className="row">
            <div className="col-12">
                <div className="shadow shadow-intensity-md rounded-3 mt-4 mb-4 p-4">
                    <h5 className="text-center">No record avaialble</h5>
                </div>
            </div>
        </div>
    )
}
export default Record404;
