import React from 'react'
import '../assets/css/Core.css';
import Logo from '../components/Logo';

function Navbar() {
    return (
        <>
            {/* Nav Bar Start  */}
            <div className="navbar navbar-expand-lg shadow-sm p-2 bg-body rounded sticky-top border-bottom">
                <div className="container">
                    <Logo />
                    <button type="button" className="navbar-toggler bg-light" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse justify-content-end " id="navbarCollapse">
                        <div className="navbar-nav ml-auto ">
                            <ul className="navbar-nav">
                                <li className="nav-item">
                                    <a href="/dashboard" className="nav-link rwt-txt-dark-blue fw-bold">DASHBOARD</a>
                                </li>
                                <li className="nav-item">
                                    <a href="/accounts" className="nav-link rwt-txt-dark-blue fw-bold">ACCOUNTS</a>
                                </li>
                                <li className="nav-item">
                                    <a href="/setting" className="nav-link rwt-txt-dark-blue fw-bold">SETTINGS</a>
                                </li>
                                <li className="nav-item dropdown">
                                    <a className="nav-link dropdown-toggle rwt-txt-dark-blue fw-bold" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">NOTIFICATION</a>
                                    <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <a className="dropdown-item" href="/payment">Payment</a>
                                        <a className="dropdown-item" href="/ticket">Ticket</a>
                                    </div>
                                </li> 
                                <li className="nav-item">
                                    <a href="/logout" className="nav-link rwt-txt-dark-blue fw-bold">LOG OUT</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>  
            {/* Nav Bar End   */}
        </>
    )
}

export default Navbar;
