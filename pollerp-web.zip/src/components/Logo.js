import React from 'react'

function Logo() {
    return (
        <div>
            <a href="home" className="navbar-brand"> <img src="https://rapidwildtutor.com/assets/images/tutor_logo.png" alt="" /></a>
        </div>
    )
}
export default Logo;
