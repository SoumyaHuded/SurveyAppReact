import React, { forwardRef, useImperativeHandle, useRef, useEffect,useState } from 'react'
import { Modal } from 'bootstrap';

const ConfirmWindow  = forwardRef(({ invokeConfirmationBox, deleteRecord,DisableSubmitButton,closeConfirmationBox}) => {
	const [Id, setId] = useState(null);
	useEffect(() => {
		invokeConfirmationBox.current = showModal
		// closeConfirmationBox.current = hideModal
	}, [])
	const initDeleteRecord = (id) => {
		deleteRecord(id)
	}
	const modalRef = useRef()
	const showModal = (id) => {
		setId(id)
		const modalEle = modalRef.current
		const bsModal = new Modal(modalEle, {
			backdrop: 'static',
			keyboard: false
		})
		bsModal.show()
	}
	const hideModal = () => {
		const modalEle = modalRef.current
		const bsModal = Modal.getInstance(modalEle)
		bsModal.hide()
	}
	useImperativeHandle(closeConfirmationBox, () => ({
		hideModal
	}),[]);
	return (
		<div className="modal fade" ref={modalRef} tabIndex="-1" >
			<div className="modal-dialog">
				<div className="modal-content">
				<div className="modal-header">
					<h5 className="modal-title" id="staticBackdropLabel">Modal title</h5>
					<button type="button" className="btn-close" onClick={hideModal} aria-label="Close"></button>
				</div>
				<div className="modal-body">
					Are you sure you want to delete this record?
				</div>
				<div className="modal-footer">
					<button type="button" className="btn btn-secondary" onClick={hideModal}>Close</button>
					<button type="button" className="btn btn-primary" disabled={DisableSubmitButton} onClick={() => initDeleteRecord(Id)}>Delete</button>
				</div>
				</div>
			</div>
		</div>
	)
});
export default ConfirmWindow;
