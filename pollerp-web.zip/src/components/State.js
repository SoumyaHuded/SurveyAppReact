import React from 'react'
import axios from "axios";  
import Config from "../config/index";

function LocationState(props) {
    const baseURL = `${Config.apiUrl}state.php/state?token=12`;
    const [State, setstate] = React.useState(null);
    React.useEffect(() => {
        axios.get(baseURL).then((response) => {
            setstate(response.data);
        });
    }, []); 
    const handleChange=((val)=>{ 
        props.locationFunction('state', val.target.value) 
    })
    if (!State) return <div>Loading state values</div>;
    return (
        <>
            <select {...props.register("state", { required: true })} value={props.selectedValue} className="form-control custom-select" onChange={handleChange} >
                <option value=""> Choose...</option>
                {(State) ? State.map((element) => { 
                    return (<option key={Math.random()} value={element.id}>{element.name}</option>)
                }) : ''}
            </select>
            <small className="form-text text-danger">
                {props.errors.state?.type === "required" && "State is mandatory"}
            </small>
        </>
    )
}
export default LocationState;