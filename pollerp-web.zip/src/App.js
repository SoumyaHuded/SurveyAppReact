import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import Dashboard from './pages/dashboard/Dashboard';
import Password from './pages/Password'; 
import Logout from './pages/Logout';
import Setting from './pages/settings/Setting';
import PaymentList from './pages/payments/List';
import TicketList from "./pages/tickets/List";
import AccountList from "./pages/accounts/List";
import AddAccountForm from "./pages/accounts/Form";
import View from "./pages/accounts/View";

function App() {
  return (
    <>
      <Router>
        <Switch>
        <Route path="/password" component={Password} />
        <Route path="/logout" component={Logout} />
        <Route path="/ticket" component={TicketList} />
        <Route path="/payment" component={PaymentList} />
        <Route path="/setting" component={Setting} />
        <Route exact path="/accounts" component={AccountList} />
        <Route path="/accounts/add" component={AddAccountForm} />
        <Route path="/accounts/edit/:id" component={AddAccountForm} />
        <Route path="/accounts/view/:id" component={View} />
        <Dashboard />
        </Switch>
      </Router>
    </>
  );

}

export default App;
