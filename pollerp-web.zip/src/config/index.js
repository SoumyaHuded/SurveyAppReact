export default {
    "apiUrl": "http://demo.rapidwildtechnologies.com/rwt-poll/public/",
    "secretKey": "12345"
}

